
package st10284733_progpart2_pranayappanna;
import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class Register {
     public String username;
     public String password;
    
    // this checks if the username meets the given conditions
    public String checkUsername(){
         boolean valid = false;
        while(!valid){
             username = JOptionPane.showInputDialog("Please enter a username that is 5 characters long and contains an  underscore "+"(_)"+":");
             
             
             if(username.length() <= 5 && username.contains("_")){
                 JOptionPane.showMessageDialog(null,"Username successfully captured");
                 valid = true;
             }
             else{
                 JOptionPane.showMessageDialog(null,"Format incorrect");
                 
             }    
        }
        return username;
    }
    // this checks if the password meets the given conditions
public boolean checkPasswordComplexity(){
String specialChars = "!@#$%^&*()_-+={}[]:;<>,.?/";

boolean isValid = false;
while (!isValid) {
    password = JOptionPane.showInputDialog("Please enter an 8 character password which contains a capital letter, a number, and a special character: ");

    if (password.length() >= 8 && password.matches(".*[A-Z].*") && password.matches(".*\\d+.*")) {
        boolean containsSpecialChar = false;
        for (int i = 0; i < password.length(); i++) {
            if (specialChars.contains(Character.toString(password.charAt(i)))) {
                containsSpecialChar = true;
                break;
            }
        }
        if (containsSpecialChar) {
            JOptionPane.showMessageDialog(null, "Password successfully captured");
            isValid = true;
        } else {
            JOptionPane.showMessageDialog(null, "Password format incorrect. Please include a special character from the following list: " + specialChars);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Password format incorrect. Please include a capital letter, a number, and it has to be 8 characters or longer.");
    }
}

return isValid;

}    
}
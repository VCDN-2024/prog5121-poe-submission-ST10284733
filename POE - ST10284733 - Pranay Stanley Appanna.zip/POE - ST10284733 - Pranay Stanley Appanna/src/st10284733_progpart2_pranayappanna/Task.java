//Refrencing List
//https://www.w3schools.com/java/java_arrays.asp
//https://chatgpt.com/c/e40bcfac-d030-49f9-8388-73c49d0fc29d
//https://www.geeksforgeeks.org/arrays-in-java/

package st10284733_progpart2_pranayappanna;
 import javax.swing.JOptionPane;

public class Task {

    // Define your arrays or collections here, these are example of what to do 
    static String[] Developer = {"John Doe", "Jane Smith", "Michael Johnson"};
    static String[] TaskNames = {"Task A", "Task B", "Task C"};
    static String[] TaskID = {"T001", "T002", "T003"};
    static int[] TaskDuration = {5, 7, 3};
    static String[] TaskStatus = {"done", "in progress", "done"};

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");

        boolean loggedIn = login();

        if (loggedIn) {
            int numTasks = getNumberOfTasks();

            int choice;
            do {
                choice = showMainMenu();
                switch (choice) {
                    case 1:
                        addTasks(numTasks);
                        break;
                    case 2:
                        showReport();
                        break;
                    case 3:
                        JOptionPane.showMessageDialog(null, "Exiting EasyKanban. Goodbye!");
                        break;
                    case 4:
                        displayDoneTasks();
                        break;
                    case 5:
                        displayLongestTaskDuration();
                        break;
                    case 6:
                        searchTaskByName(JOptionPane.showInputDialog("Enter the Task Name to search:"));
                        break;
                    case 7:
                        displayTasksByDeveloper(JOptionPane.showInputDialog("Enter the Developer Name to search tasks:"));
                        break;
                    case 8:
                        deleteTaskByName(JOptionPane.showInputDialog("Enter the Task Name to delete:"));
                        break;
                    case 9:
                        displayFullReport();
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.");
                }
            } while (choice != 3);
        } else {
            JOptionPane.showMessageDialog(null, "Login unsuccessful. Exiting EasyKanban.");
        }
    }

    private static boolean login() {
        // Placeholder for login logic
        return true; // For demonstration purposes, always return true
    }

    private static int getNumberOfTasks() {
        // Placeholder for getting number of tasks
        String input = JOptionPane.showInputDialog("Enter the number of tasks:");
        return Integer.parseInt(input);
    }

    private static int showMainMenu() {
        String[] options = {"Add tasks", "Show report", "Quit", "Display tasks with 'done' status",
                "Display longest task duration", "Search task by name", "Display tasks by developer",
                "Delete task by name", "Display full report"};
        int choice = JOptionPane.showOptionDialog(null, "Choose an option:", "Main Menu", JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
        return choice + 1;
    }

    private static void addTasks(int numTasks) {
        JOptionPane.showMessageDialog(null, "Adding " + numTasks + " tasks...");
        // Placeholder for adding tasks
    }

    private static void showReport() {
        JOptionPane.showMessageDialog(null, "This feature is still in development. Coming Soon!");
        // Placeholder for showing report
    }

    private static void displayDoneTasks() {
        System.out.println("Tasks with status 'done':");
        for (int i = 0; i < TaskStatus.length; i++) {
            if (TaskStatus[i].equalsIgnoreCase("done")) {
                System.out.println("Developer: " + Developer[i] + ", Task Name: " + TaskNames[i] + ", Task Duration: " + TaskDuration[i]);
            }
        }
    }

    private static void displayLongestTaskDuration() {
        int maxDuration = -1;
        int index = -1;
        for (int i = 0; i < TaskDuration.length; i++) {
            if (TaskDuration[i] > maxDuration) {
                maxDuration = TaskDuration[i];
                index = i;
            }
        }
        if (index != -1) {
            System.out.println("Task with longest duration:");
            System.out.println("Developer: " + Developer[index] + ", Duration: " + TaskDuration[index]);
        }
    }

    private static void searchTaskByName(String name) {
        boolean found = false;
        for (int i = 0; i < TaskNames.length; i++) {
            if (TaskNames[i].equalsIgnoreCase(name)) {
                System.out.println("Task found:");
                System.out.println("Task Name: " + TaskNames[i] + ", Developer: " + Developer[i] + ", Status: " + TaskStatus[i]);
                found = true;
                break; // Assuming task names are unique, break once found
            }
        }
        if (!found) {
            System.out.println("Task with name '" + name + "' not found.");
        }
    }

    private static void displayTasksByDeveloper(String developerName) {
        boolean found = false;
        System.out.println("Tasks assigned to " + developerName + ":");
        for (int i = 0; i < Developer.length; i++) {
            if (Developer[i].equalsIgnoreCase(developerName)) {
                System.out.println("Task Name: " + TaskNames[i] + ", Status: " + TaskStatus[i]);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No tasks assigned to developer '" + developerName + "'.");
        }
    }

    private static void deleteTaskByName(String name) {
        boolean found = false;
        for (int i = 0; i < TaskNames.length; i++) {
            if (TaskNames[i].equalsIgnoreCase(name)) {
                System.out.println("Deleting task: " + TaskNames[i]);
                TaskNames[i] = ""; // Or set to null, depending on array type
                TaskID[i] = "";
                TaskDuration[i] = 0; // Reset duration
                TaskStatus[i] = ""; // Reset status
                found = true;
                break; // Assuming task names are unique, break once deleted
            }
        }
        if (!found) {
            System.out.println("Task with name '" + name + "' not found.");
        }
    }

    private static void displayFullReport() {
        System.out.println("Full Report of Tasks:");
        for (int i = 0; i < TaskNames.length; i++) {
            System.out.println("Task Name: " + TaskNames[i] + ", Developer: " + Developer[i] + ", Status: " + TaskStatus[i] + ", Duration: " + TaskDuration[i]);
        }
    }
}

//Code attribution
//- Author name: GeekforGeek
//- Date​: 14 Mar, 2024
//- Title of program/source code​:Arrays in Java
//- Code version​: 1
//- Type: Java​
//- Web address or publisher: 

//Code attribution
//- Author name: ChatGpt
//- Date​:6 July 2023
//- Title of program/source code​: Ai
//- Code version​: 4
//- Type: Java​
//- Web address or publisher:

//Code attribution
//- Author name: w3schools
//- Date​: unknown
//- Title of program/source code​: Arrays in loop
//- Code version​: 1
//- Type: Java​
//- Web address or 
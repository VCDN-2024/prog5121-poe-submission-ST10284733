/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10284733_progpart2_pranayappanna;

/**
 *
 * @author lab_services_student
 */
class JOptionPaneTestUtil {

    static void setInput(String string) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    static void setOption(int i) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    static void setExpectedOutput(String adding_5_tasks) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
}

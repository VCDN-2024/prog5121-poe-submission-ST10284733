
package st10284733_progpart2_pranayappanna;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class TaskTest {

    private Task task;

    @Before
    public void setUp() {
        // Initialize any necessary objects or data before each test
        task = new Task(); // Assuming Task class is instantiated here
    }

    @After
    public void tearDown() {
        // Clean up any resources after each test
        task = null;
    }

    @Test
    public void testDisplayDoneTasks() {
        // Assuming you have predefined test data in Task class
        // Set up the Task arrays with some test data
        task.Developer = new String[]{"John Doe", "Jane Smith", "Michael Johnson"};
        task.TaskNames = new String[]{"Task A", "Task B", "Task C"};
        task.TaskDuration = new int[]{5, 7, 3};
        task.TaskStatus = new String[]{"done", "in progress", "done"};

        // Expected output
        String expectedOutput = "Developer: John Doe, Task Name: Task A, Task Duration: 5\n" +
                                "Developer: Michael Johnson, Task Name: Task C, Task Duration: 3\n";

        // Capture console output for testing
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        // Call the method to test
        task.displayDoneTasks();

        // Assert that the output matches the expected output
        assertEquals(expectedOutput, outContent.toString());
    }

    // Repeat similar @Test methods for other methods in Task.java
    // Example:
    @Test
    public void testDisplayLongestTaskDuration() {
        // Set up test data
        task.TaskDuration = new int[]{5, 7, 3};

        // Expected output
        String expectedOutput = "Developer: Jane Smith, Duration: 7\n";

        // Capture console output for testing
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        // Call the method to test
        task.displayLongestTaskDuration();

        // Assert that the output matches the expected output
        assertEquals(expectedOutput, outContent.toString());
    }

    // Add more @Test methods for other functionalities like search, delete, full report, etc.
}